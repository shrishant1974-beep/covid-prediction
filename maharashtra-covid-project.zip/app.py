from flask import Flask, jsonify, send_file
from flask_mysqldb import MySQL

app = Flask(__name__, static_folder=".", static_url_path="")

app.config["MYSQL_HOST"] = "localhost"
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = "password"
app.config["MYSQL_DB"] = "maharashtra_covid"

mysql = MySQL(app)


@app.route("/")
def index():
    return send_file("index.html")


@app.route("/api/summary")
def get_summary():
    cursor = mysql.connection.cursor()
    cursor.execute(
        """
        SELECT
            COALESCE(SUM(new_cases), 0),
            COALESCE(SUM(daily_deaths), 0),
            COALESCE(SUM(daily_recovered), 0)
        FROM covid_daily
        """
    )
    total_cases, total_deaths, total_recovered = cursor.fetchone()
    cursor.close()

    active_cases = max(total_cases - total_deaths - total_recovered, 0)
    fatality_rate = round((total_deaths / total_cases) * 100, 2) if total_cases else 0.0

    return jsonify(
        {
            "total_cases": int(total_cases),
            "total_deaths": int(total_deaths),
            "total_recovered": int(total_recovered),
            "active_cases": int(active_cases),
            "fatality_rate": float(fatality_rate),
        }
    )


@app.route("/api/districts")
def get_districts():
    cursor = mysql.connection.cursor()
    cursor.execute(
        """
        SELECT
            d.district_id,
            d.district_name,
            COALESCE(SUM(c.new_cases), 0) AS total_cases,
            COALESCE(SUM(c.daily_deaths), 0) AS total_deaths,
            COALESCE(SUM(c.daily_recovered), 0) AS total_recovered,
            MIN(c.report_date) AS first_report_date,
            MAX(c.report_date) AS last_report_date,
            COUNT(DISTINCT c.report_date) AS reporting_days
        FROM districts d
        LEFT JOIN covid_daily c
            ON c.district_id = d.district_id
            AND c.report_date BETWEEN '2019-01-01' AND '2020-12-31'
        GROUP BY d.district_id, d.district_name
        ORDER BY d.district_name
        """
    )

    rows = cursor.fetchall()
    cursor.close()

    data = []
    for row in rows:
        total_cases = int(row[2])
        total_deaths = int(row[3])
        total_recovered = int(row[4])
        data.append(
            {
                "district_id": int(row[0]),
                "district_name": row[1],
                "district": row[1],
                "total_cases": total_cases,
                "total_deaths": total_deaths,
                "total_recovered": total_recovered,
                "active_cases": total_cases - total_deaths - total_recovered,
                "fatality_rate": round((total_deaths / total_cases) * 100, 2) if total_cases else 0.0,
                "first_report_date": row[5].strftime("%Y-%m-%d") if hasattr(row[5], "strftime") else row[5],
                "last_report_date": row[6].strftime("%Y-%m-%d") if hasattr(row[6], "strftime") else row[6],
                "reporting_days": int(row[7]),
                "has_historical_data": row[5] is not None,
            }
        )

    return jsonify(data)


@app.route("/api/covid")
def get_covid():
    cursor = mysql.connection.cursor()
    cursor.execute(
        """
        SELECT
            c.report_date,
            d.district_name,
            c.new_cases,
            c.daily_deaths,
            c.daily_recovered
        FROM covid_daily c
        JOIN districts d
            ON c.district_id = d.district_id
        ORDER BY c.report_date, d.district_name
        """
    )

    rows = cursor.fetchall()
    cursor.close()

    data = [
        {
            "date": row[0].strftime("%Y-%m-%d") if hasattr(row[0], "strftime") else row[0],
            "district": row[1],
            "cases": int(row[2]),
            "deaths": int(row[3]),
            "recovered": int(row[4]),
        }
        for row in rows
    ]

    return jsonify(data)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)