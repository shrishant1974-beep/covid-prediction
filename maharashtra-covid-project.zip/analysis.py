from __future__ import annotations


def calculate_summary(cursor):
    cursor.execute(
        """
        SELECT
            COALESCE(SUM(new_cases), 0),
            COALESCE(SUM(daily_deaths), 0),
            COALESCE(SUM(daily_recovered), 0)
        FROM covid_daily
        """
    )
    total_cases, total_deaths, total_recovered = cursor.fetchone()

    active_cases = max(int(total_cases) - int(total_deaths) - int(total_recovered), 0)
    fatality_rate = round((int(total_deaths) / int(total_cases)) * 100, 2) if total_cases else 0.0

    return {
        "total_cases": int(total_cases),
        "total_deaths": int(total_deaths),
        "total_recovered": int(total_recovered),
        "active_cases": active_cases,
        "fatality_rate": float(fatality_rate),
    }


def top_districts(cursor, limit=5):
    cursor.execute(
        """
        SELECT
            d.district_name,
            SUM(c.new_cases) AS total_cases,
            SUM(c.daily_deaths) AS total_deaths,
            SUM(c.daily_recovered) AS total_recovered
        FROM covid_daily c
        JOIN districts d
            ON c.district_id = d.district_id
        GROUP BY d.district_name
        ORDER BY total_cases DESC
        LIMIT %s
        """,
        (limit,),
    )
    return [
        {
            "district": row[0],
            "total_cases": int(row[1]),
            "total_deaths": int(row[2]),
            "total_recovered": int(row[3]),
        }
        for row in cursor.fetchall()
    ]
